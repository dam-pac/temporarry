# О файле calc.py
Это программа, написанная на языке программирования Python.
Эта программа не имеет значения, это самый обычный калькулятор.
Этот репозиторий был создан исключительно для скачивания с него файлов через git.
Если вы очень хотите испробывать бесполезную программу, то можете его скачать.    
# Запуск
Для запуска **необходимы библиотеки**, это:    
+ Colorama - pip install colorama      
+ Asciimatics - pip install asciimatics    
+ Requests - pip install requests    
+ Keyboard - pip install keyboard    
+ Datetime - pip install datetime    
+ Pyglet - pip install pyglet    
Вы можете их установить, скачав файл install.py. После скачивания файла необходимо в командной строке написать для linux:    
```bash
python3 install.py    
```    
Для Windows:    
```bash
install.py
```     
